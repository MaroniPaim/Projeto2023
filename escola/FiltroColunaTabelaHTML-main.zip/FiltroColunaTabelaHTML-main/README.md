  
   <div style="display: inline_block" align="center"><br>
     <img align="center" height="40" width="40" src="https://lksistemas.com.br/img/icons/JavaScript.svg">
     <img align="center" height="40" width="40" src="https://lksistemas.com.br/img/icons/HTML.svg">
     <img align="center" height="40" width="40" src="https://lksistemas.com.br/img/icons/CSS.svg">
     <img align="center" height="40" width="40" src="https://lksistemas.com.br/img/icons/JQuery.svg">
</div>

<h1># Filtro de Coluna para Tabela HTML</h1>
Um filtro de colunas para uma tabela HTML, com CSS básico e utilizando JQuery
